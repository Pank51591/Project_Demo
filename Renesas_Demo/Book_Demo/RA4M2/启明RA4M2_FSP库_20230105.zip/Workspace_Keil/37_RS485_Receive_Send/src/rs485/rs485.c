#include "rs485.h"
#include "bsp_debug_uart.h"

void RS485_1_Init(void)
{
    R_SCI_UART_Open(rs485_1.p_ctrl, rs485_1.p_cfg);

}

void rs485_send_example(void)
{
    //uart_callback_args_t * g_rs485_tx_frame;

    uint8_t data;

    for (uint32_t i = 0; i < 5; i++)
    {
        data = (uint8_t) i;
    }

    R_SCI_UART_Write (&rs485_1_ctrl, (uint8_t*) &data, 1);
}

void rs485_1_callback(uart_callback_args_t * p_args)
{
    switch(p_args->event)
    {
        case UART_EVENT_RX_CHAR:
            R_SCI_UART_Write (&g_uart0_ctrl, (uint8_t*) &p_args->data, 1);
            break;
        default:
            break;
    }
}
