#include "key.h"
#include "rs485.h"
#include "bsp_led.h"



void external_irq_callback(external_irq_callback_args_t *p_args)
{
    (void)(p_args);

    /*将RS485设置为发送模式*/
    RS485_1_TX;

    LED1_ON;
    LED3_OFF;

    /*等待发送完毕*/
    R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);

    rs485_send_example();

}
