#ifndef __BSP_AGT_PWM_OUTPUT_H
#define __BSP_AGT_PWM_OUTPUT_H
#include "hal_data.h"

void AGT_PWM_Init(void);

void AGT_PWM_SetDuty(uint8_t duty);

#endif
