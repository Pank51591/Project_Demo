#ifndef __BSP_AGT_TIMING_H
#define __BSP_AGT_TIMING_H
#include "hal_data.h"

void AGT_Timing_Init(void);

#endif
