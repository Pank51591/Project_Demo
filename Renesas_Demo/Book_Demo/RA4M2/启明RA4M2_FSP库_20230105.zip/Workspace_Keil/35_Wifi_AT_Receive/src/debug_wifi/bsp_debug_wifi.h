#ifndef BSP_DEBUG_WIFI_BSP_DEBUG_WIFI_H_
#define BSP_DEBUG_WIFI_BSP_DEBUG_WIFI_H_
#include "hal_data.h"

void Debug_WIFI_Init(void);




#endif
