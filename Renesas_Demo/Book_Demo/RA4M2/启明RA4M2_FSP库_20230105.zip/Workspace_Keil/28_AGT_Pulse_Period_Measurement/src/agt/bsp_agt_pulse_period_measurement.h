#ifndef __BSP_AGT_PULSE_PERIOD_MEASUREMENT_H
#define __BSP_AGT_PULSE_PERIOD_MEASUREMENT_H
#include "hal_data.h"

void AGT_Pulse_Period_Measurement_Init(void);

#endif
