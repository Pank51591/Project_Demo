#ifndef __BSP_GPT_TIMING_H
#define __BSP_GPT_TIMING_H
#include "hal_data.h"

void GPT_Timing_Init(void);

#endif
