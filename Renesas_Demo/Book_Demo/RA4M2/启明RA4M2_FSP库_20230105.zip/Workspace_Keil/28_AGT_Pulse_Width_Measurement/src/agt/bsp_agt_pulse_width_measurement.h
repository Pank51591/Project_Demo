#ifndef __BSP_AGT_PULSE_WIDTH_MEASUREMENT_H
#define __BSP_AGT_PULSE_WIDTH_MEASUREMENT_H
#include "hal_data.h"

void AGT_Pulse_Width_Measurement_Init(void);

#endif
