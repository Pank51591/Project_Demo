#include "bsp_adc.h"

volatile bool scan_complete_flag = false;
void adc_callback(adc_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    scan_complete_flag = true;
}

void adc_Init(void)
{
    fsp_err_t err;
    err = R_ADC_Open(ADC.p_ctrl, ADC.p_cfg);
    err = R_ADC_ScanCfg(ADC.p_ctrl, ADC.p_channel_cfg);
    assert(FSP_SUCCESS == err);
}


double adc_read(void)
{
    uint16_t adc_data;
    double a0;

    (void)R_ADC_ScanStart(ADC.p_ctrl);
    scan_complete_flag = false;

    while (!scan_complete_flag)
    {
        ;
    }

    R_ADC_Read(ADC.p_ctrl, ADC_CHANNEL_0, &adc_data);
    a0 = (double)(adc_data * 3.3 / 4095);
    return a0;
}
