/*
 * bsp_uart.h
 *
 *  Created on: 2022年7月18日
 *      Author: embedfire-野火 www.embedfire.com
 */

#ifndef BSP_UART_H_
#define BSP_UART_H_
#include "hal_data.h"
#include <stdio.h>



void Debug_UART0_Init(void);
#endif /* BSP_UART_H_ */
