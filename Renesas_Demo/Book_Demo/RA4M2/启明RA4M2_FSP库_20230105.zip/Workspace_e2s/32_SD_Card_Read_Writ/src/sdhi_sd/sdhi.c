#include "sdhi.h"
#include "led/bsp_led.h"


uint32_t g_transfer_complete = 0;
uint32_t g_card_erase_complete = 0;

bool g_card_inserted = false;

/* The callback is called when a transfer completes. */
   void g_sdmmc0_callback(sdmmc_callback_args_t *p_args)
   {
       if (SDMMC_EVENT_TRANSFER_COMPLETE == p_args->event)  //读取或写入完成
       {
           g_transfer_complete = 1;
       }
       if (SDMMC_EVENT_CARD_INSERTED == p_args->event)  //卡插入中断
       {
           g_card_inserted = true;
       }
       if (SDMMC_EVENT_CARD_REMOVED == p_args->event)   //卡拔出中断
       {
           g_card_inserted = false;
       }
       if (SDMMC_EVENT_ERASE_COMPLETE == p_args->event)  //擦除完成
       {
           g_card_erase_complete = 1;
       }
       if (SDMMC_EVENT_ERASE_BUSY == p_args->event)  //擦除超时
       {
           g_card_erase_complete = 2;
       }

   }
