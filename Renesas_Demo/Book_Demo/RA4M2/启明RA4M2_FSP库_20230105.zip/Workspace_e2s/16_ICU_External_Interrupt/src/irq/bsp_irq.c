#include "bsp_irq.h"
#include "led/bsp_led.h"

bsp_io_level_t button1_status = BSP_IO_LEVEL_LOW;                                           //状态结构体
bsp_io_level_t button2_status = BSP_IO_LEVEL_LOW;

/* 按键一的中断服务函数 */
void button1_callback(external_irq_callback_args_t *p_args)                                    //当产生中断时会访问中断服务函数
{
    (void) p_args;
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_GREEN, button1_status);    //点亮LED
    button1_status=~ button1_status;                                                            //状态反转
}

/* 按键二的中断服务函数 */
void button2_callback(external_irq_callback_args_t *p_args)                                    //当产生中断时会访问中断服务函数
{
    (void) p_args;
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_BULE, button2_status);    //点亮LED
    button2_status=~ button2_status;                                                            //状态反转
}

/* IRQ初始化函数 */
void IRQ_Init(void)
{
    /* 初始化外部中断*/
    R_ICU_ExternalIrqOpen(button1.p_ctrl,button1.p_cfg);
    R_ICU_ExternalIrqEnable(button1.p_ctrl);
    R_ICU_ExternalIrqOpen(button2.p_ctrl, button2.p_cfg);
    R_ICU_ExternalIrqEnable(button2.p_ctrl);
}
