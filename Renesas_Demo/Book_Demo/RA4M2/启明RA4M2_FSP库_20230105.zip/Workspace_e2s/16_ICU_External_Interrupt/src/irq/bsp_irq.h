#ifndef __BSP_IRQ_H
#define __BSP_IRQ_H
#include "hal_data.h"


/* IRQ初始化函数 */
void IRQ_Init(void);

#endif
