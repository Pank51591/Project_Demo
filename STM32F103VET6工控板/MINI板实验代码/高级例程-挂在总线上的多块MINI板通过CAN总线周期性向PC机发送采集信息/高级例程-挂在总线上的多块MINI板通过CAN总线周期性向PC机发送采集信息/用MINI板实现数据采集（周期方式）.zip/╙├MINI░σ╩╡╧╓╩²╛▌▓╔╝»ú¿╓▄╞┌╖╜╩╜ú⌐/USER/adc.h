#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"
void ADC1_Init(void);
void filter(void);

#define  N   50              //ÿͨ����50��
#define  M  4               //Ϊ4��ͨ��
#endif /* __ADC_H */

