#ifndef __SYS_H
#define __SYS_H	
#include "stm32f10x.h"
void NVIC_Configuration(void);	
#endif
